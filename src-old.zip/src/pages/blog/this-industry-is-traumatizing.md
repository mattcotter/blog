---
layout: ../../layouts/BlogPostLayout.astro
title: 'This Industry Is Traumatizing'
pubDate: 2026-07-24
description: "Insights into my Web Development Career"
author: 'Matt Cotter'
image:
    url: '/public/astro-to-wordpress.jpg'
    alt: 'Astro to Wordpress'
tags: ["personal", "career"]
---

I loved making websites before I was sold on the future of programming. I made my first site on AOL Hometown, a WYSIWYG website editor. I remember it being very basic and outgrowing trying to make it work very quickly, but I built my first website on it regardless. It wasn't pretty. It had a bright, textured background and animated GIFs with zero structure behind its content. I actually showed it to people.

Years later, Google and other tech companies began worrying about a shortage of programmers. They began investing in programs at schools; they said it was imperative that Americans knew how to program so they could hire as many as they could. Where is that future we were promised?

